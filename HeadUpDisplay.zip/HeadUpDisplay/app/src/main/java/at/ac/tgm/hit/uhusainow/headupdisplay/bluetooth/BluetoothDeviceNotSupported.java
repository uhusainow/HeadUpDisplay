package at.ac.tgm.hit.uhusainow.headupdisplay.bluetooth;

public class BluetoothDeviceNotSupported extends Exception {
}
