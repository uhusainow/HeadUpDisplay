package at.ac.tgm.hit.uhusainow.headupdisplay.bluetooth;

public class BluetoothNotEnabled extends Exception {
}
